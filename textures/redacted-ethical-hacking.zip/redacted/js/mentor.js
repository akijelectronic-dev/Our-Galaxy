/**
 * এআই মেন্টর — ব্রাউজারেই চলা জ্ঞানভিত্তিক সহকারী।
 * নিজের এআই API ব্যবহার করতে চাইলে MENTOR_ENDPOINT-এ আপনার সার্ভারের URL দিন।
 * (API key কখনও ফ্রন্টএন্ড কোডে রাখবেন না; সার্ভার দিয়ে প্রক্সি করুন।)
 */
const MENTOR_ENDPOINT = "";

const BLOCKED = ["হ্যাক করে দাও", "পাসওয়ার্ড চুরি", "ফেসবুক হ্যাক", "ওয়াইফাই হ্যাক", "ransomware বানা", "malware বানা", "ddos"];

const KNOWLEDGE = [
  { keys: ["ইথিক্যাল", "ethical"], answer: "ইথিক্যাল হ্যাকিং মানে মালিকের লিখিত অনুমতি নিয়ে সিস্টেমের দুর্বলতা খুঁজে বের করা এবং সারানোর পরামর্শ দেওয়া। উদ্দেশ্য ক্ষতি নয়, সুরক্ষা।" },
  { keys: ["sql", "এসকিউএল"], answer: "SQL injection হলো ইনপুটের মাধ্যমে ডেটাবেস কোয়েরি বদলে ফেলার দুর্বলতা। প্রতিরোধ: parameterized query, ইনপুট যাচাই, ন্যূনতম ডেটাবেস অনুমতি। DVWA বা Juice Shop-এ নিরাপদে অনুশীলন করো।" },
  { keys: ["xss"], answer: "XSS-এ আক্রমণকারী পেজে নিজের স্ক্রিপ্ট ঢোকানোর সুযোগ পায়। প্রতিরোধ: আউটপুট escape করা, Content-Security-Policy ব্যবহার, ও HttpOnly কুকি।" },
  { keys: ["nmap", "স্ক্যান"], answer: "Nmap হলো নেটওয়ার্কে কোন হোস্ট ও পোর্ট খোলা আছে তা দেখার টুল। শুধু নিজের ল্যাব বা অনুমতি পাওয়া সিস্টেমে চালাবে। অন্যের নেটওয়ার্ক স্ক্যান বেআইনি হতে পারে।" },
  { keys: ["শুরু", "কীভাবে শিখ", "roadmap", "রোডম্যাপ"], answer: "শুরুর ক্রম:\n১. নেটওয়ার্কিং ও লিনাক্স\n২. HTTP ও ওয়েব ধারণা\n৩. OWASP Top 10\n৪. TryHackMe-র নতুনদের রুম\n৫. রিপোর্ট লেখা অভ্যাস" },
  { keys: ["owasp"], answer: "OWASP Top 10 হলো ওয়েব অ্যাপের সবচেয়ে সাধারণ ১০টি ঝুঁকির তালিকা। ওয়েব নিরাপত্তা শেখার সেরা প্রথম ধাপ।" },
  { keys: ["পাসওয়ার্ড", "password"], answer: "নিজেকে রক্ষা করতে: প্রতিটি সাইটে আলাদা লম্বা পাসওয়ার্ড, একটি পাসওয়ার্ড ম্যানেজার, আর সম্ভব হলে 2FA চালু রাখো।" },
  { keys: ["ক্যারিয়ার", "চাকরি", "সার্টিফিকেশন", "certification"], answer: "জনপ্রিয় পথ: CompTIA Security+ দিয়ে ভিত্তি, তারপর eJPT বা PNPT, পরে OSCP। পাশাপাশি bug bounty রিপোর্ট ও ল্যাব রাইট-আপ পোর্টফোলিও হিসেবে কাজে লাগে।" }
];

const FALLBACK = "এই বিষয়ে আমার কাছে নির্দিষ্ট উত্তর নেই। ইথিক্যাল হ্যাকিং, SQL injection, XSS, Nmap, OWASP, রোডম্যাপ বা ক্যারিয়ার নিয়ে প্রশ্ন করে দেখো।";
const REFUSAL = "এটা আমি সাহায্য করতে পারব না, কারণ অন্যের অ্যাকাউন্ট বা সিস্টেমে অননুমোদিত আক্রমণ বেআইনি ও ক্ষতিকর। চাইলে নিজের অ্যাকাউন্ট কীভাবে সুরক্ষিত রাখবে বা নিরাপদ ল্যাবে কীভাবে শিখবে, তা বলতে পারি।";

/** প্রশ্ন নিয়ে { text, warn } ফেরত দেয়। */
async function askMentor(question) {
  const q = question.toLowerCase();
  if (BLOCKED.some((w) => q.includes(w))) return { text: REFUSAL, warn: true };

  if (MENTOR_ENDPOINT) {
    try {
      const res = await fetch(MENTOR_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question })
      });
      const data = await res.json();
      if (data.answer) return { text: data.answer, warn: false };
    } catch (err) {
      console.error("মেন্টর সার্ভারে সংযোগ ব্যর্থ:", err);
    }
  }

  const hit = KNOWLEDGE.find((item) => item.keys.some((k) => q.includes(k)));
  return { text: hit ? hit.answer : FALLBACK, warn: false };
}
