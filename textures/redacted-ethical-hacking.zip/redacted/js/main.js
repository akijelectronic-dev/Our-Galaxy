/* রিড্যাক্ট প্রভাব ও চ্যাট UI */
(function () {
  "use strict";

  // হিরো: লোডের পর ক্রমান্বয়ে দাগ সরে যায়; ট্যাপ করলে আবার ঢাকে/খোলে
  const bars = document.querySelectorAll(".redact");
  bars.forEach((el, i) => {
    el.setAttribute("role", "button");
    el.tabIndex = 0;
    el.addEventListener("click", () => el.classList.toggle("open"));
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); el.classList.toggle("open"); }
    });
    setTimeout(() => el.classList.add("open"), 1100 + i * 700);
  });

  // চ্যাট
  const log = document.getElementById("log");
  const input = document.getElementById("q");
  const chips = document.getElementById("chips");
  const SUGGESTIONS = ["ইথিক্যাল হ্যাকিং কী?", "SQL injection কী?", "কীভাবে শুরু করব?", "ক্যারিয়ার পথ"];

  function addMessage(text, who, warn) {
    const div = document.createElement("div");
    div.className = "msg " + who + (warn ? " warn" : "");
    div.textContent = text;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
  }

  async function send(text) {
    const question = text.trim();
    if (!question) return;
    addMessage(question, "user");
    input.value = "";
    const reply = await askMentor(question);
    addMessage(reply.text, "bot", reply.warn);
  }

  SUGGESTIONS.forEach((s) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = s;
    b.addEventListener("click", () => send(s));
    chips.appendChild(b);
  });
  document.getElementById("go").addEventListener("click", () => send(input.value));
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") send(input.value); });

  addMessage("হ্যালো! আমি তোমার সাইবার নিরাপত্তা মেন্টর। কী জানতে চাও?", "bot");
})();
